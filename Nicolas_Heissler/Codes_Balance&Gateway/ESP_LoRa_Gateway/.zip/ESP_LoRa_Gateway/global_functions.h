#ifndef global_functions_h
#define global_functions_h

enum fonts {OB10=1, OB16, OB24, OB36, OC10, OC16, OC24, OC36, OC44, AP10, AP16, AP24, OC16B2}; // available fonts 
// need to modify ./libraries/...../OLEDDisplayFonts.h


#endif /* global_functions_h */
